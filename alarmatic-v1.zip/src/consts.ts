export const UPLOAD_NEW_TUNE = 'Загрузить ещё (в разработке)';
