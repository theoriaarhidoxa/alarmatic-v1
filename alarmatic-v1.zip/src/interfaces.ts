export interface ITrack {
    title: string;
    url: string;
    disabled: boolean;
}
